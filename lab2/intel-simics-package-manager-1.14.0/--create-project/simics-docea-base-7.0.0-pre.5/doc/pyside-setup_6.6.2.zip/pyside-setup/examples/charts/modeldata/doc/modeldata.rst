Model Data Example
=====================

This example shows how to use the QAbstractTableModel derived model as the data
for the series.

.. image:: modeldata.png
   :width: 400
   :alt: Model Data Screenshot
