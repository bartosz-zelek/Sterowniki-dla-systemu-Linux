Bars 3D Example
===============

The bars example shows how to make a 3D bar graph using Q3DBars.

.. image:: simple3d.png
   :width: 400
   :alt: Bards 3D Screenshot
