.. _qml-binding-example:

Extending QML - Binding Example
===============================

This example builds on the :ref:`qml-adding-types-example`,
the :ref:`qml-attached-properties-example`,
the :ref:`qml-default-property-example`,
the :ref:`qml-inheritance-and-coercion-example`
the :ref:`qml-object-and-list-property-types-example`
and the :ref:`qml-valuesource-example`.

Running the Example
-------------------

The ``main.py`` file in the example includes a simple shell application that
loads and runs the QML snippet shown below.
