# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.6.1
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x02e\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 fi\
ll=\x22#0d0d0d\x22><pa\
th d=\x22M8.41 18.1\
38L12 15.845l3.5\
9 2.323-.94-4.34\
5 3.162-2.897-4.\
159-.392L12 6.43\
l-1.652 4.073-4.\
159.392 3.162 2.\
927-.94 4.315zm-\
1.346 3.696a1.04\
 1.04 0 0 1-1.56\
7-1.104l1.318-6.\
033-4.476-4.11c-\
.665-.611-.293-1\
.726.604-1.808l5\
.866-.539 2.229-\
5.587c.348-.872 \
1.575-.872 1.923\
 0l2.229 5.587 5\
.866.539c.897.08\
2 1.269 1.197.60\
4 1.808l-4.476 4\
.11 1.318 6.033a\
1.04 1.04 0 0 1-\
1.567 1.104L12 1\
8.681l-4.935 3.1\
53z\x22/><path d=\x22M\
12 5l-1.796 5.52\
8H4.392l4.702 3.\
416-1.796 5.528L\
12 16.056l4.702 \
3.416-1.796-5.52\
8 4.702-3.416h-5\
.812L12 5z\x22/></s\
vg>\x0a\
\x00\x00\x01\xfa\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 fi\
ll=\x22none\x22><path \
d=\x22M8.41 18.138L\
12 15.845l3.59 2\
.323-.94-4.345 3\
.162-2.897-4.159\
-.392L12 6.43l-1\
.652 4.073-4.159\
.392 3.162 2.927\
-.94 4.315zm-1.3\
46 3.696a1.04 1.\
04 0 0 1-1.567-1\
.104l1.318-6.033\
-4.476-4.11c-.66\
5-.611-.293-1.72\
6.604-1.808l5.86\
6-.539 2.229-5.5\
87c.348-.872 1.5\
75-.872 1.923 0l\
2.229 5.587 5.86\
6.539c.897.082 1\
.269 1.197.604 1\
.808l-4.476 4.11\
 1.318 6.033a1.0\
4 1.04 0 0 1-1.5\
67 1.104L12 18.6\
81l-4.935 3.153z\
\x22 fill=\x22#0d0d0d\x22\
/></svg>\x0a\
"

qt_resource_name = b"\
\x00\x06\
\x07\x03}\xc3\
\x00i\
\x00m\x00a\x00g\x00e\x00s\
\x00\x0f\
\x02\x11 \x07\
\x00s\
\x00t\x00a\x00r\x00-\x00f\x00i\x00l\x00l\x00e\x00d\x00.\x00s\x00v\x00g\
\x00\x08\
\x0a\x85U\x87\
\x00s\
\x00t\x00a\x00r\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x12\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8c\xd4\xc79\xcf\
\x00\x00\x006\x00\x00\x00\x00\x00\x01\x00\x00\x02i\
\x00\x00\x01\x8c\xd4\xc79\xcf\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
