Threaded QOpenGLWidget Example
==============================

The threaded QOpenGLWidget example demonstrates OpenGL rendering
in separate threads.

.. image:: threadedqopenglwidget.png
   :width: 400
   :alt: Threaded QOpenGLWidget Example Screenshot
