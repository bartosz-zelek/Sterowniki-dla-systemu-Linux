Chart Themes Example
====================

The example shows the look and feel of the different built-in themes.

This example shows the look and feel of the different built-in themes for some
of the supported chart types.

.. image:: chartthemes.png
   :width: 400
   :alt: Chart Themes Screenshot
