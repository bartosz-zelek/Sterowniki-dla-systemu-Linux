Pandas Simple Example
=====================

A Python application that demonstrates how to visualize
a Pandas DataFrame.

.. image:: pandas_simple.png
   :width: 400
   :alt: Pandas Simple Screenshot
