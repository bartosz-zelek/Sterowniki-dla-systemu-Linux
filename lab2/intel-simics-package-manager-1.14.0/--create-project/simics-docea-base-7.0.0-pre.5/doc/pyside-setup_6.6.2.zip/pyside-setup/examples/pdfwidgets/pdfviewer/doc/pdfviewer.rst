PDF Viewer Example
==================

The PDF Viewer example demonstrates how to use the QPdfView class to render
PDF documents and the QPdfPageNavigator class to navigate them.
