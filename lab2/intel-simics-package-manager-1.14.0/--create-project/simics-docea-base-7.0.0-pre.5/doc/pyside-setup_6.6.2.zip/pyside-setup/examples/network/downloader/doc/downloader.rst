Downloader Example
==================

A Python application that demonstrates how to create a simple downloader
application based on Qt Widgets.

.. image:: downloader.png
   :width: 400
   :alt: Downloader Screenshot
