Text Properties Example
=======================

A Python application that demonstrates how to load a qml file
using Material design, to change the look of text.

.. image:: textproperties.png
   :width: 400
   :alt: Text Properties Screenshot
