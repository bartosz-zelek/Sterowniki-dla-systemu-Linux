Graph Gallery
=============


Graph Gallery demonstrates all three graph types and some of their special
features. The graphs have their own tabs in the application.


.. image:: graph_gallery.webp
   :width: 400
   :alt: Graph Gallery Screenshot
