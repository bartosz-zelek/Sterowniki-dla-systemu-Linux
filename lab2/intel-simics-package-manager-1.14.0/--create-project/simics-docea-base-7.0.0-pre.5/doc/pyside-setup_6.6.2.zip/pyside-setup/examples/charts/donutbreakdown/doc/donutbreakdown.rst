Donut Chart Breakdown Example
=============================

This example shows how to use create a donut breakdown chart using QPieSeries API.

.. image:: donutbreakdown.png
   :width: 400
   :alt: Donut Chart Breakdown Screenshot
