Terminal Example
================

The Terminal Example shows how to create a terminal for a simple serial
interface by using Qt Serial Port.

It demonstrates the main features of the QSerialPort class, like configuration,
I/O implementation and so forth. Also, the class QSerialPortInfo is invoked to
display information about the serial ports available in the system.
