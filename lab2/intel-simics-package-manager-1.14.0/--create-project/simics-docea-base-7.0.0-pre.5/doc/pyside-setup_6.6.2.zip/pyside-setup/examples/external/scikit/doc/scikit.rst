Scikit Image Example
====================

A Python application that demonstrates how to use Scikit Image
to apply filters to images based on a Qt Widgets.

.. image:: scikit.png
   :width: 400
   :alt: Scikit Image Screenshot
