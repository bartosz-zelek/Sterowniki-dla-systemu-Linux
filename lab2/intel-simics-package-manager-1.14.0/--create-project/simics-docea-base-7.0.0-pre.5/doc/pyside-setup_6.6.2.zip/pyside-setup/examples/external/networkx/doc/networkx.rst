Networkx viewer Example
=======================

A Python application that demonstrates how to display networkx graph into a QGraphicsView.

.. image:: networkx.png
   :width: 400
   :alt: Networkx viewer Screenshot
