Bluetooth Low Energy Heart Rate Server
======================================

The Bluetooth Low Energy Heart Rate Server is a command-line
application that shows how to develop a Bluetooth GATT server using
the Qt Bluetooth API. The application covers setting up a GATT
service, advertising it and notifying clients about changes to
characteristic values.
