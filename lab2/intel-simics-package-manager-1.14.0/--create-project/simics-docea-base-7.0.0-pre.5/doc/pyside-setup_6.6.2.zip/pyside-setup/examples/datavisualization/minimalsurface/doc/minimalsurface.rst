Minimal Surface Example
=======================

The example shows the minimal code to create a surface.
