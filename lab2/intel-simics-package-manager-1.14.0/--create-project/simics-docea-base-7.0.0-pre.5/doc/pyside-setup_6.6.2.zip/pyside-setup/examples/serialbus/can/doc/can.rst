CAN Bus example
===============

The example sends and receives CAN bus frames. The example sends and receives
CAN bus frames. Incoming frames are ordered according to their type. A connect
dialog is provided to adjust the CAN Bus connection parameters.
