Loopback Example
================

Demonstrates the client-server communication on a local host.

The example demonstrates how the clients and servers on a local host communicate with each other.

.. image:: loopback.png
   :width: 208
   :alt: loopback program screenshot
