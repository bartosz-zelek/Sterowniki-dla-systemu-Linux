Nested Donuts Example
=====================

This example shows how to create a nested donuts chart using the QPieSeries API.

.. image:: nesteddonuts.png
   :alt: Nested Donuts Screenshot
