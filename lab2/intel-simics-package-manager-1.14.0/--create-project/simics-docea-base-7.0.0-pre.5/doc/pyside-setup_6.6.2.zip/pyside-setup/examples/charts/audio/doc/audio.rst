Audio Example
=============

This example shows the drawing of dynamic data (microphone input).

.. image:: audio.png
   :width: 400
   :alt: Audio Screenshot
