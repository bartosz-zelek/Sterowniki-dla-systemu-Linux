HTTP Server After Request Example
=================================

A Python application that demonstrates the analogous example in C++
`AfterRequest Example <https://doc.qt.io/qt-6/qthttpserver-afterrequest-example.html>`_
