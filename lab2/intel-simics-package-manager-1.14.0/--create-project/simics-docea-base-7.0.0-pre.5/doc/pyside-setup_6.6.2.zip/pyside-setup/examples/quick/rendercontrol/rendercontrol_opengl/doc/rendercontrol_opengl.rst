QQuickRenderControl OpenGL Example
==================================

The QQuickRenderControl OpenGL Example shows how to render a Qt Quick scene into a
texture that is then used by a non-Quick based OpenGL renderer.
