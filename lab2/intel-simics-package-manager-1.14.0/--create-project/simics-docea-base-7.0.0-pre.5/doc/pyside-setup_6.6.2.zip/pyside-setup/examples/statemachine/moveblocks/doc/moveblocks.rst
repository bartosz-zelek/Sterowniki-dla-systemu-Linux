Move Blocks Example
===================

The Move Blocks example shows how to animate items in a QGraphicsScene
using a QStateMachine with a custom transition.


.. image:: moveblocks.png
   :width: 400
   :alt: Move Blocks Screenshot
