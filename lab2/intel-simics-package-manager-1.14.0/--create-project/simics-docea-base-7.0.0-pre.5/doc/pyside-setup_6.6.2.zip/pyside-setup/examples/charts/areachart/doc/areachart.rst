Area Chart Example
==================

The example shows how to create an area Chart

.. image:: areachart.png
   :width: 400
   :alt: Area Chart Screenshot
