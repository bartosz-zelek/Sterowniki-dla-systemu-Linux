Traffic Light Example
=====================

The Traffic Light example shows how to use The State Machine Framework to
implement the control flow of a traffic light.


.. image:: trafficlight.png
   :width: 400
   :alt: Traffic Light Screenshot
