Player Example
==============

Media Player demonstrates a simple multimedia player that can play audio and or
video files using various codecs.

.. image:: player.png
   :width: 400
   :alt: Player Screenshot
