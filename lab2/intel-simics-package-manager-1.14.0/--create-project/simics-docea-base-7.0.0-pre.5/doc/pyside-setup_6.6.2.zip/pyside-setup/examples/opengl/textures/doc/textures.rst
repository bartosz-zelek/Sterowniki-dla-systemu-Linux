Texture Example
===============

The Textures example demonstrates the use of Qt's image classes as textures in
applications that use both OpenGL and Qt to display graphics.

.. image:: textures.png
   :width: 400
   :alt: Textures Screenshot
